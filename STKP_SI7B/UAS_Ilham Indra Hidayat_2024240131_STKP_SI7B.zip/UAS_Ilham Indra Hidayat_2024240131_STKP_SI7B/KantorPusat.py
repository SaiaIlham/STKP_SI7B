
import os,re, threading
import time

class jumlah(threading.Thread):
    def __init__(self, awal, akhir):
        threading.Thread.__init__(self)
        self.awal=awal
        self.akhir=akhir
    def run(self):
        self.hasil=0
        for self.suffix in range (self.awal, self.akhir+1):
            self.hasil = self.hasil + self.suffix
            #print(self.suffix, "=", self.hasil)
    def hasilHitung(self):
        return self.hasil

start = time.time()
#memanggil thread
hitungProduksiGudang1=jumlah(1,60000)
hitungProduksiGudang2=jumlah(60001,170000)
hitungProduksiGudang3=jumlah(170001,20000)

#menjalankan thread
hitungProduksiGudang1.start()
hitungProduksiGudang2.start()
hitungProduksiGudang3.start()

#menampilkan hasil thread
hitung1Hasil = hitungProduksiGudang1.hasilHitung()
hitung2Hasil = hitungProduksiGudang2.hasilHitung()
hitung3Hasil = hitungProduksiGudang3.hasilHitung()
end = time.time()

totalHitung = hitung1Hasil + hitung2Hasil  + hitung3Hasil
print(hitung1Hasil, "+", hitung2Hasil, "+" hitung3Hasil "=", totalHitung)

print(end-start)
