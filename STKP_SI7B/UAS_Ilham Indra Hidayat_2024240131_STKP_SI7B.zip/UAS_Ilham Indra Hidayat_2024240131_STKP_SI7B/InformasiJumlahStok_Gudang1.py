# menyimpan informasi stok barang di Gudang 1
stok_barang = {
    "beras": 10000,
    "gula": 50000,
}

# mencetak daftar stok barang
print("Daftar stok barang:")
for barang, jumlah in stok_barang.items():
    print(f"{barang}: {jumlah}")

# meminta input nama barang dari user
nama_barang = input("Masukkan nama barang yang ingin Anda cek stoknya di Gudang 1: ")

# mengecek apakah barang tersebut tersedia di gudang 1 atau tidak
if nama_barang in stok_barang:
    # jika tersedia, menampilkan jumlah stok barang 
    print(f"Stok {nama_barang} di Gudang 1 adalah {stok_barang[nama_barang]}")
else:
    # jika tidak tersedia, menampilkan pesan kesalahan
    print(f"Maaf, stok tidak tersedia di Gudang 1, silahkan cari stok barang yang lain {nama_barang}.")
